Due to Massive polygon inflation of outsourced assets. All the models imported from Unity, is stripped from this Project by default. However, all the outsourced assets should be free to use/import in the project.

Thus, from the Unity Asset Store; here's a list of all the assets used;

-----

Tim's Assets - Old Ceiling Fan, by Tim.H
https://assetstore.unity.com/packages/3d/props/tim-s-assets-old-ceiling-fan-103789

ArchViz Sofa Pack - Lite, by Cassdalla
https://assetstore.unity.com/packages/3d/props/furniture/archviz-sofa-pack-lite-95228

Free Rug Pack, by Azerilo
https://assetstore.unity.com/packages/3d/props/interior/free-rug-pack-118178

Toon Furniture, by Elcanetay
https://assetstore.unity.com/packages/3d/props/furniture/toon-furniture-88740

TV Furniture, by Enozone
https://assetstore.unity.com/packages/3d/props/electronics/tv-furniture-60122

TV Set, by Dmitriy Dryzhak
https://assetstore.unity.com/packages/3d/props/electronics/tv-set-26193

Low Poly Office Props - LITE, by RRFreelance / PiXelBurner
https://assetstore.unity.com/packages/3d/environments/low-poly-office-props-lite-131438

Classic Interior Door Pack 1, by Jan Fidler
https://assetstore.unity.com/packages/3d/props/interior/classic-interior-door-pack-1-118744

Food Pack - 3D Microgames Add-Ons, by Unity Technologies
https://assetstore.unity.com/packages/3d/food-pack-3d-microgames-add-ons-163295
