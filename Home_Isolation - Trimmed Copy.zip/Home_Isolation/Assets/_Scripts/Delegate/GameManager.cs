﻿/* Discard using System.Collections default, as it's not required for this script
using System;
using System.Collections;
using System.Collections.Generic;*////for List support, Options and Arrays wise
using UnityEngine;
using UnityEngine.SceneManagement;
//future libraries to use, for Options set up/editing. Thank Brackey's for the sauce
using UnityEngine.Audio;
using UnityEngine.UI;
/** Sources for Options
 * https://www.red-gate.com/simple-talk/dotnet/c-programming/how-to-create-a-settings-menu-in-unity/
 * https://www.youtube.com/watch?v=YOaYQrN1oYQ&list=PLeuCp0u_Tyx9bmndbmNThbhMqDgOBj4l4&index=28
 */

/**************************************************
*    Title: GameManager
*    Author: Andrew Irvine Letailleur
*    Date: 25/11/2020
*    Code version: 1.0
*    Availability: Here
*    ===============
*    References: Brackey's (Tutorial, on Options)
**************************************************/

//function of GameManager, is to manage the state of the game, whilst it is running. As such, there should only be one Game Manager at any time.
public class GameManager : MonoBehaviour
{
#region Singleton Setup
    /** extra stuff,
    * Possibly better pattern is from this source;
    * https://gamedev.stackexchange.com/questions/116009/in-unity-how-do-i-correctly-implement-the-singleton-pattern
    * private static GameManager Singleton;
    * public static GameManager Instance { get { return Singleton; } }
    */ //if sauce is implemented. "Public Static" would be the 'instance', while private Static would be the 'Singleton', ideally.
    public static GameManager gm;//the Singleton in-class, check. From lecture. Stick with this base, for now
    #endregion
#region State Setup
    public enum Ending { Quit, Fall, Sick, Life, Game}
    public Ending GameState;
    //int day lasted
    #endregion
#region Options Setup
    //options set up, for user friendliness. Disabled for now, as it's not fully implemented/supported in build just yet.
    /*
    public AudioMixer audioMixer;//ideally, let it grab naturally
    public Resolution[] resolutions;//an array, to grab/set up all native resolution options
    public Dropdown resolution_GUI;//for the dropdown menu, bias wise. That will ensure it is selected right.
    */
#endregion

    //Awake is called when the script instance is being loaded
    void Awake() { //the singleton pattern is created first, to make sure only one "GameManager" exists at a time. Then the state is set to "Game" by default.
#region Singleton Pattern
        if (gm != null && gm != this) Destroy(this.gameObject);
        else gm = this; //class, or (this) script.
        DontDestroyOnLoad(this);//to ensure it stays itself.
        //Debug.Log(gm);//end Singleton Pattern, to a hack degree
#endregion
        //Options set up, once everything is done
#region Options Pattern
        /*
        resolutions = Screen.resolutions;//For all Full-screen resolutions natively supported by the monitor (Unity)
        resolution_GUI.ClearOptions();//wipes all existing options/lists within the Dropdown menu for resolutions
        List<string> options = new List<string>();//a new list of options, system wise. For the Dropdown menu

        int currentResolutionIndex = 0;//count at 0, increment by computer logic and math
        for (int i = 0; i < resolutions.Length; i++) {
            string option = resolutions[i].width + " x " + resolutions[i].height;//set a text decription for options
            options.Add(option);//then add it to the dropdown list

            if (resolutions[i].width == Screen.currentResolution.width &&
                resolutions[i].height == Screen.currentResolution.height)
            { currentResolutionIndex = i; }//additional checker of resolutions, just in case. Then increment index
        }//end for
        resolution_GUI.AddOptions(options);//add the list of options text, to the Dropdown menu
        resolution_GUI.value = currentResolutionIndex;//set the current value/amount of the dropdown menu, to the current resolution
        resolution_GUI.RefreshShownValue();//then reset the Dropdown menu
        */
#endregion
        //end patterns
        GameState = Ending.Game;//set the GameState to 'game' by default, and not any other ending for Menu setup purposes.
    }//end Awake

    //LoadEnding is called, when an end game condition is met. Where it will load the menu scene again, with a changed game state.
    public void LoadEnding(Ending NewGameState) {//loads the ending, switching the 'game state' to a est variable for the ending panel
        GameState = NewGameState;
        SceneManager.LoadScene(0);
    }//end LoadEnding

    //all the Option variables that could alter the current settings of the game itself.
#region Options Functions
    /*
    public void SetVolume(float volume)//could do/be used for/with bgm, sfx and voice?
    { audioMixer.SetFloat("volume", volume); }//end SetVolume
    public void SetQuality(int qualityIndex)//for graphics quality, asset rendering wise
    { QualitySettings.SetQualityLevel(qualityIndex); }//end SetQuality
    public void SetFullscreen(bool _Fullscreen)//to go fullscreen or windowed mode
    { Screen.fullScreen = _Fullscreen; }//end SetFullscreen
    public void SetResolution(int resolutionIndex)//to set the Resolution to a chosen index
    {
        Resolution resolution = resolutions[resolutionIndex];
        Screen.SetResolution(resolution.width, resolution.height, Screen.fullScreen);
    }//end SetResolution
    */
    //misc Options that haven't been planned/set up yet, GUI Wise.
    //public void SetGUI(?? ??) { }         //TODO: To alter the GUI Options/display, visual wise
    //public void SetCamera(?? ??) { }      //TODO: Camera settings, movement, zoom/clipping, etc
    //public void SetKeybindings(?? ??) { } //TODO: Set alternate controls in order to dodge say, a "Funky" S Key
    //public void SetGameplay(?? ??) { }    //TODO: Adjust/alter difficulty and gameplay related settings
    //public void SetMisc(?? ??) { }        //TODO: Anything else that can be included later, or as a cool feature
    //brightness, gamma/etc.    //TODO: IE: Is it super white/black in color tone, I barely notice myself?
    //end options
#endregion
    //end Options Functions

    /* Not used or needed. Even if it could be more secure if used.
    public Ending ReturnTheState()
    { return GameState; } */

}
