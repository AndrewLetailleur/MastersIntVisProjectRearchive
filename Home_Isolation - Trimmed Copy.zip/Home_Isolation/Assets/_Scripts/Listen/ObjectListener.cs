﻿using UnityEngine;
using TMPro;//for editing the UI text, intead of UnityEngine.UI;
using CustomGUI;//to alter the GUI_Manager, class reference

/**************************************************
*    Title: ObjectListener
*    Author: Andrew Irvine Letailleur
*    Date: 25/11/2020
*    Code version: 1.0
*    Availability: Here
*    ===============
*    References: None
**************************************************/

//function of ObjectListener, is to alter the GUI_Manager to a certain state, depending on if it's highlighted or interacted with.
public class ObjectListener : MonoBehaviour
{
    //three public strings, for general decription, action reaction, and disabled action. Default value's are also listed;
    public string text = "...";
    public string action = "That was entertaining!";
    public string unable = "Too tired to act.";

    //GUI Values, including the GUI_Manager variable to call from
    TextMeshProUGUI tGUI;
    GUI_Manager gui_M;

    //the State management system. Specifically, on what action to take for altering the GUI_Manager
    public enum Action { Activity, Outdoors, Sleeping, Cleanup, Blank}
    public Action choice;
    //game manager get

    //Awake is called when the script instance is being loaded
    private void Awake() {
        tGUI = GameObject.FindWithTag("GUI_Text").GetComponent<TextMeshProUGUI>();
        gui_M = FindObjectOfType<GUI_Manager>();
    }//end Awake

    //OnMouseExit is called when the mouse entered the GUIElement or Collider
    private void OnMouseEnter()//on mouse hovering in
    { tGUI.text = text; }//end OnMouseEnter

    //OnMouseExit is called when the mouse is no longer over the GUIElement or Collider
    private void OnMouseExit()//on mouse hovering out
    { tGUI.text = ""; }//end OnMouseExit

    //OnMouseDown is called when the user has pressed the mouse button while over the GUIElement or Collider
    private void OnMouseDown() {//on click
        switch (choice) {//all hail the glorious switch cases, and enum sums!
            case Action.Activity://Standard action
                if (gui_M.turn > 0) { gui_M.Increase();
                    tGUI.text = action;
                } else tGUI.text = unable; 
                break;
            case Action.Outdoors://If going outside action
                if (gui_M.turn > 0) {
                    if (gui_M.sick > 0) tGUI.text = "Can't go out, I'm ill!";
                    else { gui_M.BigIncrease();
                        tGUI.text = "Glad I got some sunshine!";
                    }
                } else { tGUI.text = unable; }
                break;
            case Action.Sleeping://when resting, reset time and increment days
                if (gui_M.sick > 0) { tGUI.text = "I am infected, and sick. Need to stay at home."; }
                else if (gui_M.mind > 50) tGUI.text = "Today is a Brand new day!";
                else tGUI.text = "Today is a Brand new day.";
                gui_M.EndTurn();
                break;
            case Action.Cleanup: //future action, to reduce sickness chance
                gui_M.LessSick();
                tGUI.text = "That should keep me free from ailments.";
                break;
            //end case
        }//end switch, later else; "Rest time reset"
    }//end OnMouseDown
}//end ObjectListener