﻿using UnityEngine;
using UnityEngine.SceneManagement;

/**************************************************
*    Title: MenuListener
*    Author: Andrew Irvine Letailleur
*    Date: 25/11/2020
*    Code version: 1.0
*    Availability: Here
*    ===============
*    References: None
**************************************************/

//function of MenuListener, is to listen to the GameManager, and edit menu panels depending on it's current state upon loading
public class MenuListener : MonoBehaviour
{
    GameManager manager;
    public GameObject endObj;

    //Start is called on the frame when a script is enabled just before any of the Update methods are called the first time
    private void Start()
    {
        Checker();//Invoke("Checker", 0);//https://answers.unity.com/questions/799637/delay-the-start-function.html
    }
    
    //Checker is used as an "invoke", for a slight delay to ensure the GameManager is grabbed appropiately.
    void Checker() {
        while (manager == null) { manager = GameObject.FindGameObjectWithTag("GameManager").GetComponent<GameManager>(); }
        //Debug.Log("Check done. And it's");//Debug.Log(manager);
        if (manager.GameState != GameManager.Ending.Game) { MenuSet(false, true); }
        else { MenuSet(true, false); }//flips the ending and menu panels to active/inactive, depending on game state
    }//end Checker

    //MenuSet determine's if a certain panel is active or inactive, on load. Menu wise
    void MenuSet(bool menu, bool ending) {
        //main menu panel
        GameObject menuObj = GameObject.FindGameObjectWithTag("Menu");
        menuObj.SetActive(menu);
        //ending panel
        endObj = GameObject.FindGameObjectWithTag("Ending");
        endObj.SetActive(ending);
        //if ending is true, check for which ending panel is active
        if (ending) EndCheck(endObj);
    }//end MenuSet

    //if ending is selected, EndCheck keeps active the precise ending panel, and disables the rest
    public void EndCheck(GameObject endObj) {

        switch (manager.GameState) {//switch case, that uses enum state for more english worded cases, state wise
            case GameManager.Ending.Quit://if player quit early
                foreach (Transform child in endObj.transform)
                {
                    if (child.tag != "Quit_E") { if (child.tag != "GUI_End") child.gameObject.SetActive(false); }
                }
                break;
            case GameManager.Ending.Fall://if mind is at zero
                foreach (Transform child in endObj.transform)
                {
                    if (child.tag != "Fall_E") { if (child.tag != "GUI_End") child.gameObject.SetActive(false); }
                }
                break;
            case GameManager.Ending.Sick://if player got hospitalised
                foreach (Transform child in endObj.transform)
                {
                    if (child.tag != "Sick_E") {if (child.tag != "GUI_End") child.gameObject.SetActive(false); }
                }
                break;
            case GameManager.Ending.Life://if the lockdown ended
                foreach (Transform child in endObj.transform)
                {
                    if (child.tag != "Life_E") { if (child.tag != "GUI_End") child.gameObject.SetActive(false); }
                }
                break;
            default:
                MenuSet(true, false);
                break;
            //end cases
        }//end switches

        //sets GameState back to default, upon ending
        manager.GameState = GameManager.Ending.Game;
    }//end EndCheck

    //Load the game scene, once called
    public void PlayGame()
    { SceneManager.LoadScene(1); }//end PlayGame

    //exit game, in build. Should disable, if WebGL Build
    public void Close()
    { Application.Quit(); }//end Close
}//end MenuListener