﻿using UnityEngine;
using UnityEngine.UI;//for editing the general UI;
using TMPro;//for editing the UI text, intead of UnityEngine.UI;

/**************************************************
*    Title: GUI_Manager
*    Author: Andrew Irvine Letailleur
*    Date: 25/11/2020
*    Code version: 1.0
*    Availability: Here
*    ===============
*    References: None
**************************************************/
namespace CustomGUI
{
    //function of GUI_Manager, is to manage the state of "player condition", during gameplay. As such, there should only be one GUI_Manager at any time.
    public class GUI_Manager : MonoBehaviour
    {
        public GameManager gm; //reference the static class
#region GameStats
            //"RPG-lite" Stats variables. Should be ideally set to private.
        public bool wentOut = false;
        [Range(0, 4)] public int turn = 4;
        public int MaxDays = 100;
        public int days = 1;
        [Range(0, 100)] public int mind = 100;
        [Range(0, 14)] public int sick = 0;
            //rng statistics, should again, ideally be private.
        [Range(0f, 100f)] private float rng;
        [Range(0, 100)] public int sickChance = 0;
        [Range(0, 100)] public int deathChance;
        #endregion
        //condition flags, GUI Wise
        private AudioSource sfx;//the sound to play when ill
        TextMeshProUGUI condition;//start with text
        TextMeshProUGUI days_in;//description wise
        Image timeGUI, mindIMG, sickIMG;//link to "Turn"
        Slider mindBAR;//set's the "Bar" to be adjusted
        /*consider 'hiding' the Mental Health hud
        * For immersion purposes */

        //Awake is called when the script instance is being loaded
        void Awake() {
            gm = Object.FindObjectOfType<GameManager>();
            gm.GameState = GameManager.Ending.Game;//game start
            condition = GameObject.FindWithTag("GUI_Con").GetComponent<TextMeshProUGUI>();
            condition.text = "<color=#00ff00>Condition: Fine</color>";//Debug.Log("text = " + condition.text);

            days_in = GameObject.FindWithTag("GUI_Days").GetComponent<TextMeshProUGUI>();
            days_in.text = "Day: " + days;//Debug.Log("text = " + condition.text);

            sfx = GameObject.FindWithTag("SFX").GetComponent<AudioSource>();
            sfx.playOnAwake = false;
            sfx.loop = false; //disables ssfx looping assurely, jnc

            mindBAR = GameObject.FindWithTag("MP_Bar").GetComponent<Slider>();
                //screen backgrounds
            mindIMG = GameObject.FindWithTag("IMG_Mind").GetComponent<Image>();
            sickIMG = GameObject.FindWithTag("IMG_Sick").GetComponent<Image>();
                //day counter
            timeGUI = GameObject.FindWithTag("GUI_Time").GetComponent<Image>();
                //update the GUI
            TimeGUI();
            GuiUpdate();
        }//end Awake

        //TimeGUI is called to update the visual display
        void TimeGUI() { timeGUI.fillAmount = 0.25f * turn; }

        //GuiUpdate is called, to update the GUI once values are altered
        void GuiUpdate() {
            Color alph = new Color(1, 1, 1, 1);// Each color component is a floating point value with a range from 0 to 1. 
            float alphF = ((100f - mind) / 100);//alpha value. Set to mind value math logic
            alph.a = alphF;
            mindIMG.color = alph;
            mindBAR.value = mind;// Debug.Log(alph.a + " is the value of mind!");

            if (sick > 0) {//death rate affect transparency of red.
                alphF = (deathChance / 100f);
                alph.a = alphF;
                Debug.Log(alph.a + " is the value!");
                sickIMG.color = alph;
            } else {
                alph.a = 0;
                sickIMG.color = alph;
            }
        }

        //BigIncrease is only called, if player goes outside.
            //There, they have the risk/chance of getting ill/infected.
        public void BigIncrease() {
            if (sick > 0) { }//can't go out, I'm ill!
            else {//you can go out, however...
                mind += Random.Range(10, 21);//big boost for going outside
                if (mind > 100) mind = 100;
                wentOut = true;
                sickChance += 20;//increase sick chance if )
                if (sickChance > 100) sickChance = 99;
                turn--;
                TimeGUI();//decrement time, then update time
                GuiUpdate();//then update GUI
            }
        }
        //Increase is called if a player performs an indoor action
        public void Increase() {
            mind += Random.Range(0, 7);
            if (mind > 100) mind = 100;
            turn--;
            TimeGUI();//decrement time, then update time
            GuiUpdate();//then update GUI
        }

        //LessSick is called, if player "washes hands"
        public void LessSick() {
            sickChance -= 15;
            turn--;
            TimeGUI();//decrement time, then update time
        }

        //turn ends, when prompted in-game or by button
        public void EndTurn() {
            turn = 4;
            days++;//update time
            days_in.text = "Day: " + days;

            if (sickChance > 0) {
                if (sickChance - 15 > 0) sickChance -= 15;//safety valve
                else sickChance = 0;//safety valve 0
            }//end sick chance check

            //if player went out, check for ailment/infection
            if (wentOut) {
                wentOut = !wentOut;//make it false
                rng = Random.Range(0f, 100f);
                //limit the check to above X chance of getting ill
                //this is to reward, not punish the player for hygene.
                if (rng < sickChance && sickChance > 21) {
                    sick = 14; condition.text = "<color=#ff0000>Condition: Sick</color>";
                    //Debug.Log("text = " + condition.text);}//you get infected, condition trig
                }//end outing check
                //first outing shouldn't be deadly. Subsequent ones, should up the 'risk'.
                if (sickChance + 40 < 100) sickChance += 40;//up to 100, who knows
                else sickChance = 100;
            } else { mind -= Random.Range(3, 9); } //lower mind, if you did not go out


            //the conditional turn eat options, that also lower mind even more... To a degree
            rng = Random.Range(0f, 100f);
            if (rng > mind) turn--;
            
            if (!wentOut) {
                if (mind < 50) { mind -= Random.Range(-1, 6); if (rng > (mind * 2)) turn--; }
                if (mind < 25) { mind -= Random.Range(-1, 6); if (rng > (mind * 3)) turn--; }
            }

            //from here on, are "ending Enum set" conditions, for later 'Menu editing' purposes, GUI wise.
            if (mind < 1) { gm.LoadEnding(GameManager.Ending.Fall); }
            if (sick > 0) { sickCheck(); }//risk of gm.LoadScene(GameManager.Ending.Sick);
            else MaxDays--;//the "clock"
            if (MaxDays < 1) { gm.LoadEnding(GameManager.Ending.Life); }
            TimeGUI();
            GuiUpdate();
        }//end EndTurn

        //sickCheck is called, for every day the player is ill
        void sickCheck() {
            sfx.Play();//should play once only
            sick--;
            deathChance += Random.Range(0, 5);
            if (deathChance < 0) deathChance = 0;
                //roll for game over con, if death chance is at a 'set' value, coin toss wise
            if (deathChance < 50) rng = 100f;
            else rng = Random.Range(0f, 100f);
                //if death check is failed, load the Sick Ending, main menu wise
            if (rng < deathChance) { Debug.Log("Died at " + (deathChance - rng) + "% Chance"); gm.LoadEnding(GameManager.Ending.Sick); }
            //reset condition to green, once healthy again
            if (sick < 1) condition.text = "<color=#00ff00>Condition: Fine</color>";
        }//end sickCheck

        //QuitGame closes the game early, if called. And has the main menu reflect on that choice
        public void QuitGame() { gm.LoadEnding(GameManager.Ending.Quit); }//end QuitGame
    }//end GUI_Manager
}//end namespace